for (let a = 1; a <= 10; a++) {
    for (let b = 1; b <= 10; b++) {
        let kq = a * b;
        document.writeln(a + ' * ' + b + ' = ' + kq + '<br>');
    };
    document.write('<br>');
}